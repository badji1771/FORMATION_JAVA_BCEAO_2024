package launch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import model.Invoice;

public class Refactor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	private static void oldSchool(List<Invoice> invoices) {

		List<Invoice> trainingInvoices = new ArrayList<>();
		for (Invoice inv : invoices) {
			if (inv.getTitle().contains("Training")) {
				trainingInvoices.add(inv);
			}
		}
		Collections.sort(trainingInvoices, new Comparator<Invoice>() {
			public int compare(Invoice inv1, Invoice inv2) {
				return inv2.getAmount().compareTo(inv1.getAmount());
			}
		});
		List<Integer> invoiceIds = new ArrayList<>();
		for (Invoice inv : trainingInvoices) {
			invoiceIds.add(inv.getId());
		}
	}

}
