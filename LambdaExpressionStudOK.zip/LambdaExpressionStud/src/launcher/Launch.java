package launcher;

import java.util.ArrayList;
import java.util.List;

import model.Animal;

public class Launch {

	public static void main(String[] args) {

		/// Play with removeIf and forEach
		List<String> bunnies = new ArrayList<>();
		bunnies.add("long ear");
		bunnies.add("floppy");
		bunnies.add("hoppy");
//		System.out.println(bunnies);
//		


		
		
		
		
		
		
		

	}
	
	
}
